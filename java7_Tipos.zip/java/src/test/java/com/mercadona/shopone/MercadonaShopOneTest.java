package com.mercadona.shopone;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MercadonaShopOneTest {

    @Test
    void itemGenericNotExpired() {
        Item[] items = new Item[] { new Item("generic", 3, 12, Tipo.GENERICO) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("generic", app.items[0].name);
        assertEquals(2, app.items[0].sellIn);
        assertEquals(11, app.items[0].quality);
    }
    
    @Test
    void qualityCapHamTest() {
        Item[] items = new Item[] { new Item("Ham", 3, 50, Tipo.CURADO)};
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Ham", app.items[0].name);
        assertEquals(2, app.items[0].sellIn);
        assertEquals(50, app.items[0].quality);

    }
    
    @Test
    void day10HamTest() {
        Item[] items = new Item[] {new Item("Ham", 10, 45, Tipo.CURADO)};
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        
        assertEquals("Ham", app.items[0].name);
        assertEquals(9, app.items[0].sellIn);
        assertEquals(47, app.items[0].quality);
    }
    
    @Test
    void day5HamTest() {
        Item[] items = new Item[] {new Item("Ham", 5, 45, Tipo.CURADO)};
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        
        assertEquals("Ham", app.items[0].name);
        assertEquals(4, app.items[0].sellIn);
        assertEquals(48, app.items[0].quality);
    }
    
    @Test
    void day20HamTest() {
        Item[] items = new Item[] {new Item("Ham", 20, 45, Tipo.CURADO)};
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        
        assertEquals("Ham", app.items[0].name);
        assertEquals(19, app.items[0].sellIn);
        assertEquals(46, app.items[0].quality);
    }
    
    @Test
    void expiredHamTest() {
        Item[] items = new Item[] {new Item("Ham", 0, 45, Tipo.CURADO)};
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        
        assertEquals("Ham", app.items[0].name);
        assertEquals(-1, app.items[0].sellIn);
        assertEquals(0, app.items[0].quality);
    }
    
    @Test
    void itemGenericExpired() {
        Item[] items = new Item[] { new Item("Bread", 0, 50, Tipo.GENERICO) , new Item("Yogurt", -1, 0, Tipo.GENERICO)};
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        
        assertEquals("Bread", app.items[0].name);
        assertEquals(-1, app.items[0].sellIn);
        assertEquals(48, app.items[0].quality);
        
        assertEquals("Yogurt", app.items[1].name);
        assertEquals(-2, app.items[1].sellIn);
        assertEquals(0, app.items[1].quality);
    }
    
    @Test
    void itemFrozenExpired() {
        Item[] items = new Item[] { new Item("Frozen cake", 0, 50, Tipo.CONGELADO)};
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        
        assertEquals("Frozen cake", app.items[0].name);
        assertEquals(-1, app.items[0].sellIn);
        assertEquals(46, app.items[0].quality);
        
    }
    
    @Test
    void itemFrozenNotExpired() {
        Item[] items = new Item[] { new Item("Frozen cake", 2, 50, Tipo.CONGELADO)};
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        
        assertEquals("Frozen cake", app.items[0].name);
        assertEquals(1, app.items[0].sellIn);
        assertEquals(48, app.items[0].quality);
        
    }
    
    @Test
    void saltTest() {
        Item[] items = new Item[] { new Item("Iodized salt", 0, 80, Tipo.INALTERABLE)};
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        
        assertEquals("Iodized salt", app.items[0].name);
        assertEquals(0, app.items[0].sellIn);
        assertEquals(80, app.items[0].quality);
        
    }
    

}
