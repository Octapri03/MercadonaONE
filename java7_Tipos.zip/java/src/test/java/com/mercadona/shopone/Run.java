package com.mercadona.shopone;

public class Run {
    public static void main(String[] args) {
        System.out.println("Welcome to Mercadona Shop One!");

        Item[] items = new Item[] {
                new Item("Bread", 10, 20, Tipo.GENERICO),
                new Item("Aged blue cheese", 2, 0, Tipo.CURADO),
                new Item("Yogurt", 5, 7, Tipo.GENERICO),
                new Item("Iodized salt", 0, 80, Tipo.INALTERABLE),
                new Item("Ham", 15, 20, Tipo.CURADO),
                new Item("Butter", 7, 14, Tipo.GENERICO),
                new Item("Frozen fish", 8, 14, Tipo.CONGELADO),
                new Item("Honey", 1, 80, Tipo.INALTERABLE),
                new Item("Potaoes", 8, 12, Tipo.GENERICO),
                new Item("Frozen cake", 1, 16, Tipo.CONGELADO) };

        MercadonaShopOne app = new MercadonaShopOne(items);

        int days = 5;
        if (args.length > 0) {
            days = Integer.parseInt(args[0]) + 1;
        }

        for (int i = 0; i < days; i++) {
            System.out.println("-------- day " + i + " --------");
            System.out.println("name, sellIn, quality");
            for (Item item : items) {
                System.out.println(item);
            }
            System.out.println();
            app.updateQuality();
        }
    }

}
