package com.mercadona.shopone;

public enum Tipo {
	GENERICO,
	CONGELADO,
	INALTERABLE,
	CURADO
}
