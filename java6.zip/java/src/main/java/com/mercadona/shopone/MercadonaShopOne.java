package com.mercadona.shopone;


public class MercadonaShopOne {
    Item[] items;

    public MercadonaShopOne(Item[] items) {
        this.items = items;
    }

    public void updateQuality() {
    	
    	for (Item item : items) {
    		
    		if (item.name.equals("Iodized salt")) {
                return;
            }
    		
    		item.sellIn -= 1;
    		
			if (item.name.equals("Aged blue cheese")) {
				
				modifyQuality(item, 1);
				if(isNotCapped(item)) {
					if (item.sellIn < 11) 
						modifyQuality(item, 1);

					if (item.sellIn < 6) 
						modifyQuality(item, 1);

				}
			
				if(isExpired(item)) {
				item.quality = 0;
				}

				return;
            }
			
			if(item.name.equals("Ham")) {
				
				modifyQuality(item, 1);
				if(isNotCapped(item)) {
					if (item.sellIn < 11) 
						modifyQuality(item, 1);

					if (item.sellIn < 6) 
						modifyQuality(item, 1);

				}
				
				if(isExpired(item)) {
					item.quality = 0;
				}

				return;
			}
			
			if(item.name.equals("Frozen cake")) {
				
				modifyQuality(item, -2);
				
				if(isExpired(item)) {
					modifyQuality(item, -2);
				}

				return;
			}

            else {
            	
            	modifyQuality(item, -1);
            	
            	if (isExpired(item)) {

            	modifyQuality(item, -1);
            	}
            }
  
    	}  
    }
    
    
    public boolean isExpired(Item item) {
    	return item.sellIn < 0;
    }
    
    public boolean isNotCapped(Item item) {
    	return item.sellIn < 50;
    }
    
    public void modifyQuality(Item item, int number){
    	int result = item.quality += number;
    	
    	if(result > 50) {
    		item.quality = 50;
    	}
    	if(result < 0) {
    		item.quality = 0;
    	}
    }
    
}
